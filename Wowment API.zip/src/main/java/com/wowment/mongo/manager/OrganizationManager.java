package com.wowment.mongo.manager;


import com.wowment.mongo.Organization;
import com.wowment.service.core.AbstractService;

public interface OrganizationManager extends AbstractService<Organization>{
	 
}

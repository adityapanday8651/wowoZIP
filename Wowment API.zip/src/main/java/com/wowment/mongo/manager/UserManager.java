package com.wowment.mongo.manager;


import com.wowment.mongo.User;
import com.wowment.service.core.AbstractService;

public interface UserManager extends AbstractService<User>{
	 
}

package com.wowment.mongo.manager;


import com.wowment.mongo.Program;
import com.wowment.service.core.AbstractService;

public interface ProgramManager extends AbstractService<Program>{
	 
}
